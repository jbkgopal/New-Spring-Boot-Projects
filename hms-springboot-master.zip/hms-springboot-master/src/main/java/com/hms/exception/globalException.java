package com.hms.exception;

public class globalException extends Exception {

	public globalException(String msg) {
		super(msg);
	}
	
}
