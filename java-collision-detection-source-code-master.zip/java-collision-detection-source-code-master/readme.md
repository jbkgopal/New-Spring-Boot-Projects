## A Collision Detection Visual Simulation


#### Its a java swing based app.


## Demo

 ![Alt Text](demo.gif)