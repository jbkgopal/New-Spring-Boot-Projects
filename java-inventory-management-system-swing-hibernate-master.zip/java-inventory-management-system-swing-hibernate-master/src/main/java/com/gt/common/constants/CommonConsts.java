package com.gt.common.constants;

import java.awt.*;


public class CommonConsts {
    public static final Color COLOR_TOOLBAR_BORDER = Color.BLACK;
}
