package com.hotelmgmt.constants;

// TODO: Auto-generated Javadoc
/**
 * The Class HotelMgmtConstants.
 * 
 * @author Gokulan
 */
public final class HotelMgmtConstants {

    /**
     * The Constant ADD_SUCCESS.
     */
    public static final String ADD_SUCCESS = " added successfully.";

    /**
     * The Constant DELETE_SUCCESS.
     */
    public static final String DELETE_SUCCESS = " deleted successfully.";

    /**
     * The Constant PATCH_SUCCESS.
     */
    public static final String PATCH_SUCCESS = " patched successfully.";

    /**
     * The Constant FILTER_COLUMN.
     */
    public static final String FILTER_COLUMN = "city";

    /**
     * The Constant FILTER_OPERATION.
     */
    public static final String FILTER_OPERATION = ":";
}
