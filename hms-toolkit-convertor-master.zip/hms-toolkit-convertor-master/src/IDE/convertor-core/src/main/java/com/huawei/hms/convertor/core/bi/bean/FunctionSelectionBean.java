/*
 * Copyright 2020. Huawei Technologies Co., Ltd. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.huawei.hms.convertor.core.bi.bean;

import lombok.Builder;
import lombok.Getter;

/**
 * Usage of some function options in the tool.
 *
 * @since 2020-03-30
 */
@Builder
@Getter
public class FunctionSelectionBean extends BaseBIData {
    /**
     * Project type.
     */
    private String projectType;

    /**
     * Indicates whether to use the comment mode.
     */
    private boolean commentMode;

    /**
     * Conversion Policy
     */
    private String strategy;

    /**
     * Indicates whether to use the variant.
     */
    private boolean variantApk;

    /**
     * Indicates whether to use only HMS SDK.
     */
    private boolean onlyH;

    /**
     * Indicates whether to use third party library scan function.
     */
    private boolean thirdPartyLibrary;
}
