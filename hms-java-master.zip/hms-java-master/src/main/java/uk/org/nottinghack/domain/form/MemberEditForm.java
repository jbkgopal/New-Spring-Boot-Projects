package uk.org.nottinghack.domain.form;

/**
 * This class encapsulates the editable fields for a member.
 *
 * @author <a href="rob.hunt@nottinghack.org.uk">Robert Hunt</a>
 */
public class MemberEditForm
{
}
