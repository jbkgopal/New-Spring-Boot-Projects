package uk.org.nottinghack.domain.tool;

/**
 * @author <a href="rob.hunt@nottinghack.org.uk">Robert Hunt</a>
 */
public enum ToolUsageStatus
{
    IN_PROGRESS,
    COMPLETE,
    CHARGED
}
