package uk.org.nottinghack.domain;

/**
 * @author <a href="rob.hunt@nottinghack.org.uk">Robert Hunt</a>
 */
public interface Described
{
    String getDescription();
}
