/**
 * Provides supporting XML-based configuration - parsers, namespace handlers.
 */
package org.springframework.integration.config.xml;
