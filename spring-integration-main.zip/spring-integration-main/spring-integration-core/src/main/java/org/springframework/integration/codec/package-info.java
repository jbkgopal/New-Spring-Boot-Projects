/**
 * Provides base classes for the {@code Codec} abstraction.
 */
package org.springframework.integration.codec;
