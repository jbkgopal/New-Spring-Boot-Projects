/**
 * Provides classes representing various channel types.
 */
@org.springframework.lang.NonNullApi
package org.springframework.integration.channel;
