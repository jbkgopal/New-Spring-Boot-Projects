/**
 * Provides classes related to dispatching messages.
 */
package org.springframework.integration.dispatcher;
