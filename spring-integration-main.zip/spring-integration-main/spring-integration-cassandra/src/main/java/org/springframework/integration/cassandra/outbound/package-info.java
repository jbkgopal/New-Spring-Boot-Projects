/**
 * Provides classes supporting Cassandra outbound endpoints.
 */
@org.springframework.lang.NonNullApi
package org.springframework.integration.cassandra.outbound;
