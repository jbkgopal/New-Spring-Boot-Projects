/**
 * Provides classes supporting outbound endpoints.
 */
package org.springframework.integration.amqp.outbound;
