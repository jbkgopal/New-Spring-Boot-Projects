/**
 * Provides AMQP support classes.
 */
package org.springframework.integration.amqp.support;
