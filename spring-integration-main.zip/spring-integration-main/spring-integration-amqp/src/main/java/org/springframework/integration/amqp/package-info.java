/**
 * Base package for AMQP support.
 */
@org.springframework.lang.NonNullApi
package org.springframework.integration.amqp;
