package sample;

/**
 * Testing this
 * @author Rob Winch
 *
 */
public class Impl {

	/**
	 * This does stuff
	 */
	public void otherThings() {}
}
