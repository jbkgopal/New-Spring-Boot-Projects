INSERT INTO AUTHOR (ID, NAME)
VALUES (42, 'Tom');

INSERT INTO BOOK (ID, TITLE, AUTHOR_ID)
VALUES (1, 'Get Your Hands Dirty on Clean Architecture', 42);