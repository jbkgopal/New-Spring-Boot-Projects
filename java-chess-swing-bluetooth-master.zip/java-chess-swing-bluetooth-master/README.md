# java-chess-swing-bluetooth
### Chess game with multi-player mode over bluetooth as well as locally
