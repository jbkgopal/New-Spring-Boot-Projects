package com.hms.dao;

public interface InvoiceDao {

}
