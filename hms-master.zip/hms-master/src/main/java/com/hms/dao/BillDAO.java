package com.hms.dao;

public interface BillDao {

}
