package com.hms.dao;

import java.util.List;

import com.hms.model.Hospital;

public interface HospitalDao {
	public List<Hospital> getHospital();
}
