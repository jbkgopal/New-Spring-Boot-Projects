package com.hms.dao.impl;

import org.springframework.stereotype.Repository;

import com.hms.dao.BillDao;

@Repository
public class BillDAOImpl implements BillDao {
	
}
