package com.hms;

import org.junit.Test;

public class ServiceTest {

	@Test
	public void testGetHospital(){
		
	}
}
