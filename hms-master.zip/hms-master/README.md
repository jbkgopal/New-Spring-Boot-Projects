# hms
Hospital Management System
This system is used to maintain hospital record like Patient and Doctor information.This Applications allows to generate Invoice for the Patient to maintain billing information.

#The Application is based on Java Spring Boot having endpoints with RESTful Services.
