/**
 * Package for classes related to spring-messaging with Kafka Streams.
 */
package org.springframework.kafka.streams.messaging;
