package flowabledemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoFlowfestApplicationTests {

	@Test
	void contextLoads() {
	}

}
