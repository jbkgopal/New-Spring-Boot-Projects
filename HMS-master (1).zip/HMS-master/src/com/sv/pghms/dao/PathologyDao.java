package com.sv.pghms.dao;

import java.util.List;

import com.sv.pghms.model.TDailyAccountOfOperationSection;

public interface PathologyDao {

	/*public boolean insert(TDailyAccountOfOperationSection dailyAccountOfOperationSection);
	public List<TDailyAccountOfOperationSection> getDailyAccountOfOperationSectionList();*/
}
