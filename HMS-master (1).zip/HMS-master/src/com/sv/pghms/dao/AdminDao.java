package com.sv.pghms.dao;

import com.sv.pghms.model.TUser;

public interface AdminDao {
	//public boolean insertUser(TUser user);
}
