package com.sv.pghms.service;

import com.sv.pghms.model.TUser;

public interface AdminService {
	//public boolean insertUser(TUser user);

}
