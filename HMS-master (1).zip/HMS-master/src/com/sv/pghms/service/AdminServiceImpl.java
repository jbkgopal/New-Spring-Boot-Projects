package com.sv.pghms.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.sv.pghms.dao.AdminDao;
import com.sv.pghms.model.TUser;

public class AdminServiceImpl implements AdminService {

	/*@Autowired
	private AdminDao adminDao;
	public boolean insertUser (TUser user){
		return adminDao.insertUser(user);
		
	}*/

}
