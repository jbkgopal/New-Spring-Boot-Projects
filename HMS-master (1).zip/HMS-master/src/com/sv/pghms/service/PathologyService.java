package com.sv.pghms.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.sv.pghms.model.TDailyAccountOfOperationSection;

@Service
public interface PathologyService {

	/*public boolean insert(TDailyAccountOfOperationSection dailyAccountOfOperationSection);
	public List<TDailyAccountOfOperationSection> getDailyAccountOfOperationSectionList();*/

}
