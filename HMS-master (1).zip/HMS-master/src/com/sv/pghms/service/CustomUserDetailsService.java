package com.sv.pghms.service;

public interface CustomUserDetailsService {

	//public TUser getUserByLoginID(String loginID);

}
