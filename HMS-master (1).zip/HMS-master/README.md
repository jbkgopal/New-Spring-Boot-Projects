Hospital Management System provide us to digital and modern eHospital service for patient.It also provide the pathology and pharmacy facilitise for patient. It has admin, patient, pathology and pharmacy module.
Technology use:
1)Java
2)Spring MVC
3)Hivernate
4)Tomcat
5)Maven
6)JavaScript
7)Spring Security
8)Thymeleaf
