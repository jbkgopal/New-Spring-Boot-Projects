$(function() { 
	
	$( "#expenseConveyanceDate" ).datepicker({ dateFormat : 'dd-M-yy' });
});
$(function() { 
	
	$( "#expenseDateFrom" ).datepicker({ dateFormat : 'dd-M-yy' });
});
$(function() { 
	
	$( "#expenseDateTo" ).datepicker({ dateFormat : 'dd-M-yy' });
});
$(function() { 
	
	$( "#reqEntryDate" ).datepicker({ dateFormat : 'dd-M-yy' });
});
$(function() { 
	
	$( "#reqDateFrom" ).datepicker({ dateFormat : 'dd-M-yy' });
});
$(function() { 
	
	$( "#reqDateTo" ).datepicker({ dateFormat : 'dd-M-yy' });
});