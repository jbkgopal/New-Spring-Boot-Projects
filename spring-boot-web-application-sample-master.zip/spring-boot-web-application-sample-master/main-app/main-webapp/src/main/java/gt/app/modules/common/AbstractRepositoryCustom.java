package gt.app.modules.common;

import gt.app.domain.BaseEntity;


public interface AbstractRepositoryCustom<T extends BaseEntity> {
}
