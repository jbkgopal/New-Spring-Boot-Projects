package gt.app.domain;

public enum ArticleStatus {
    FLAGGED_FOR_MANUAL_REVIEW, UNDER_AUTO_REVIEW, BLOCKED, PUBLISHED
}
