# Run single simulation:
- Use Engine class to run individual simulation
- Use `mvn gatling:test -Dgatling.simulationClass=gt.simulations.THE_SIMULATION_CLASS` to run specified simulation

# Run all simulations
- Use `mvn gatling:test` 

